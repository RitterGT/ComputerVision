# Problem Set 6: Optic Flow

Template code for PS6.
