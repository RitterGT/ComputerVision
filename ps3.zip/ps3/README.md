# Problem Set 3: Window-based Stereo Matching

Template code for PS3.
